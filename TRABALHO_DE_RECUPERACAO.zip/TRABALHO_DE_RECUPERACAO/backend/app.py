from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Permite chamadas do frontend (que estará em outra porta)

# Banco de dados simples em memória (lista)
mensagens = []

@app.route('/mensagens', methods=['GET'])
def listar_mensagens():
    return jsonify(mensagens)

@app.route('/mensagens', methods=['POST'])
def adicionar_mensagem():
    dados = request.get_json()
    texto = dados.get('texto')
    if texto:
        mensagens.append({'texto': texto})
        return jsonify({'status': 'ok'}), 201
    return jsonify({'error': 'Mensagem vazia'}), 400

if __name__ == '__main__':
    app.run(debug=True)
