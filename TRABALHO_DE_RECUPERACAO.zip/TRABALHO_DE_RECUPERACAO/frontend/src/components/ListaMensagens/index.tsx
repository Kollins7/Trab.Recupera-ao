import './style.css';

interface Mensagem {
  texto: string;
}

interface Props {
  mensagens: Mensagem[];
}

export default function ListaMensagens({ mensagens }: Props) {
  return (
    <div className="lista-mensagens">
      <ul>
        {mensagens.map((mensagem, index) => (
          <li key={index}>{mensagem.texto}</li>
        ))}
      </ul>
    </div>
  );
}
