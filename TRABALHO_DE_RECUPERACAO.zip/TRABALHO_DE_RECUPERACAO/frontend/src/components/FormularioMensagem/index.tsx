import React, { useState } from 'react';
import './style.css';

interface Props {
  onMensagemEnviada: () => void;
}

export default function FormularioMensagem({ onMensagemEnviada }: Props) {
  const [texto, setTexto] = useState('');

  const enviar = async () => {
    if (texto.trim() === '') return;
    await fetch('http://localhost:5000/mensagens', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ texto }),
    });
    setTexto('');
    onMensagemEnviada();
  };

  return (
    <div className="formulario">
      <input
        className="input-mensagem"
        value={texto}
        onChange={e => setTexto(e.target.value)}
        placeholder="Digite sua mensagem"
      />
      <button className="botao-enviar" onClick={enviar}>Enviar</button>
    </div>
  );
}
