import { useEffect, useState } from 'react';
import ListaMensagens from './components/ListaMensagens';
import FormularioMensagem from './components/FormularioMensagem';

interface Mensagem {
  texto: string;
}

function App() {
  const [mensagens, setMensagens] = useState<Mensagem[]>([]);

  const carregarMensagens = async () => {
    const res = await fetch('http://127.0.0.1:5000/mensagens');
    const data = await res.json();
    setMensagens(data);
  };

  useEffect(() => {
    carregarMensagens();
  }, []);

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Painel de Mensagens</h1>
      <FormularioMensagem onMensagemEnviada={carregarMensagens} />
      <ListaMensagens mensagens={mensagens} />
    </div>
  );
}

export default App;
